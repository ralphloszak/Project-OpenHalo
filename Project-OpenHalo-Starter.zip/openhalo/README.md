# Project OpenHalo

**The $0 Local AI Workstation Challenge** — a public, reproducible attempt to acquire, assemble, and benchmark a Ryzen AI Max+ 395 / 128GB unified-memory workstation using legitimately donated hardware and no personal spending.

## Hardware target
- AMD Ryzen AI Max+ 395, 16C/32T; Radeon 8060S integrated GPU; XDNA 2 NPU
- 128GB soldered LPDDR5X-8000, up to 96GB GPU-addressable allocation depending on firmware/OS
- 1TB NVMe M.2 2280 SSD minimum
- Compatible motherboard, heatsink/fan, enclosure, FlexATX power supply, AC cable and mounting hardware
- Linux OS and open-source AI inference stack

## Project principles
1. No personal out-of-pocket spending, including tax and shipping.
2. Sponsorships, donations, and loans must be labeled distinctly; a loan is not an owned build.
3. No fabricated performance claims, followers, audience metrics, sponsor promises, or product endorsements.
4. Sponsors receive factual acknowledgement, never editorial control or a guaranteed positive review.
5. Do not publish home addresses, personal phone numbers, shipping details, serial numbers or sensitive account information.
6. Record every offer, agreement, receipt and benchmark transparently.

## Status
**Planning / outreach preparation.** No hardware received, sponsorships accepted, or orders placed.

## Roadmap
- [ ] Publish repository
- [ ] Submit Framework sponsorship inquiry
- [ ] Join AMD AI Developer Program and submit project
- [ ] Secure mainboard/complete DIY kit with 128GB RAM
- [ ] Secure storage, PSU, chassis, cooling and shipping
- [ ] Inventory, assemble and validate hardware
- [ ] Install Linux and inference runtimes
- [ ] Publish reproducible benchmarks and sponsor disclosures

See docs/ for specification, acquisition tracker and testing plan.
