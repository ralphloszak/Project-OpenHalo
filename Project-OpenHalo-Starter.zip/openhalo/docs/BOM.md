# Bill of materials (target, not purchased)
| Item | Minimum | Acquisition status |
|---|---|---|
| Mainboard/CPU/RAM | Ryzen AI Max+ 395 with 128GB LPDDR5X-8000 | Needed |
| GPU | Integrated Radeon 8060S | Included with CPU |
| Heatsink and fan | Compatible with chosen mainboard and case | Needed |
| Case | Compatible Mini-ITX/Framework chassis, correct clearance | Needed |
| PSU | Compatible FlexATX or board-approved PSU, ~400W for Framework reference | Needed |
| SSD | 1TB PCIe 4.0 NVMe M.2 2280 | Needed |
| AC cable | US mains compatible, PSU-specific | Needed |
| Network | Built-in 5GbE or compatible adapter | Verify |
| Mounting parts | Standoffs, screws, I/O modules, thermal interface | Verify |
| OS | Linux | Free |

IMPORTANT: The processor and RAM are soldered, not independently upgradeable. Verify exact board revision and power connectors before accepting components. A 300W PSU from a different design is not automatically interchangeable.

Reference: https://frame.work/products/framework-desktop-mainboard-amd-ryzen-ai-max-300-series
Reference: https://frame.work/desktop
