# Acquisition ledger
| Date | Organization | Requested hardware | Contact method | Status | Ownership / shipping terms |
|---|---|---|---|---|---|
| 2026-10-16 | Framework | 128GB Ryzen AI Max+ 395 DIY system or mainboard | Sponsorship form (not yet submitted) | Draft prepared | Unconfirmed |
| 2026-10-16 | AMD | Ryzen AI Max+ 395 developer hardware or referral | ai_dev_program@amd.com (not yet sent) | Draft prepared | Unconfirmed |

Never mark a request sent until actual submission is confirmed. Record shipping and taxes as covered by sponsor or funded separately; $0 budget means $0 total out-of-pocket.
