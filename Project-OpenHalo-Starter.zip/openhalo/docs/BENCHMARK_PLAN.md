# Benchmark and validation plan

## Hardware verification
- Photograph components and document model numbers (redact serials).
- Verify CPU, memory and SSD via Linux hardware inventory.
- Record BIOS version, Linux kernel, firmware, thermal and power settings.
- Stress-test CPU, RAM, NVMe and networking; check idle/load power and temperatures.

## AI inference
- Select current AMD-compatible llama.cpp / ROCm or Vulkan stack only after confirming software support.
- Test at least 8B, 32B, and 70B-class open-weight models where licensing and memory allow.
- Report exact model name, revision, quantization, context length, prompt, tokens/sec prefill and decode, RAM use, temperatures, wall power and repeat counts.
- Separate cold and warm runs; report median of >=3 runs and raw logs.
- Compare CPU-only vs accelerated inference where supported.
- Avoid claims that 96GB is dedicated VRAM: it is allocated from shared unified memory.

## Security and reproducibility
- No patient data, client data, secrets or production infrastructure in benchmarks.
- Publish installation commands, hashes, dependencies, configuration, limitations and failures.
