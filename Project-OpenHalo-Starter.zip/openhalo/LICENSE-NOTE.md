Documentation is intended for publication under CC BY 4.0; scripts can be MIT licensed once authored. Choose and add official license texts before public repository publication.
