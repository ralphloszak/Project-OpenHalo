To: ai_dev_program@amd.com
Subject: Project OpenHalo — open-source Ryzen AI Max+ 395 128GB local AI build

Hello AMD AI Developer Program,

I'm preparing Project OpenHalo, a public, reproducible DIY build and benchmark series focused on Ryzen AI Max+ 395 with 128GB of unified memory. The project will document Linux configuration, open-weight model inference, memory behavior, throughput, power, thermals and reproducible results.

I'm seeking developer hardware sponsorship, an evaluation-to-donation opportunity, or a referral to a hardware partner willing to provide a 128GB Ryzen AI Max+ 395 platform and shipping at no cost to the project. Sponsorships will be disclosed, and the findings will remain independent.

Could you direct me to the appropriate developer-relations contact or application process?

Thank you,
[Your name]
[Public repository URL after publication]
