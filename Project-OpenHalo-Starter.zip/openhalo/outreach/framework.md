Subject: OpenHalo — public Ryzen AI Max+ 395 / 128GB DIY workstation project

Hello Framework sponsorships team,

I'm launching Project OpenHalo, an open-source, reproducible attempt to assemble and benchmark a privacy-focused local AI workstation based on the Ryzen AI Max+ 395 and 128GB of unified memory, with no personal hardware spend.

The proposed deliverables are a public bill of materials, assembly notes, Linux setup, reproducible local-model inference benchmarks, power and thermal measurements, and an honest report of successes and limitations. Hardware contributors will be disclosed and acknowledged, without editorial approval or promised positive coverage.

Would Framework consider donating a 128GB Ryzen AI Max+ 395 DIY Desktop kit or mainboard, or introducing us to a developer-hardware partner? The project would also need shipping covered to stay within the zero-dollar constraint. I'm happy to share the published repository and a detailed test plan for review.

Thank you for considering it.

[Your name]
[Public repository URL after publication]
